import java.lang.String;
import java.util.Scanner;
import java.util.ArrayList;

public class main
{
    //global scanner to make life easy (used for customer and robot aswell)
    public static Scanner s = new Scanner(System.in);

    // every Customer and Robot record is stored here
    private static ArrayList<Entity> records = new ArrayList<>();

    public static void main(String[] args)
    {   
        boolean exit = false;
        while(!exit)
        {
            exit = !checkInput();
        }
    }

    private static boolean checkInput()
    {   
        boolean valid = true;
        String input = "";

        do
        {
            valid = true;
            promptUser();
            
            input = s.nextLine();
            char c;
            if (input.length() > 1 || input.length() < 1)
                c = 'I';
            else {c = Character.toUpperCase(input.charAt(0));}

            switch (c)
            {
                case 'A':
                    addRecords();
                    break;
                case 'E':
                    editRecords();
                    break;
                case 'S':
                    searchRecords();
                    break;
                case 'R':
                    rentRobot();
                    break;
                case 'X':
                    retEquipment();
                    break;
                case 'D':
                    deliverRobot();
                    break;
                case 'P':
                    schedulePickup();
                    break;
                case 'I':
                default:
                    System.out.println("Invalid input");
                    sleep(2); //sleeps for 2seconds
                case 'W':
                    valid = false;
                    break;
                case 'Q':
                    return false;
            }
        } while (!valid);
        
        return true;
    }

    private static void promptUser()
    {
        //menu for records
        System.out.println("What would you like to do");
        System.out.println("press A, to Add new records");
        System.out.println("press E, to edit/delete records");
        System.out.println("press S, to search records");

        //menu options for robots/equipment
        System.out.println();
        System.out.println("press R, to rent a robot");
        System.out.println("press X, to return equipment");
        System.out.println("press D, to schedule delivery of robot/s");
        System.out.println("press P, to schedule pick up of robot/s");

        //quit or reprint options
        System.out.println();
        System.out.println("press W, to reprint options");
        System.out.println("press Q, to quit");
    }

    private static void sleep(int seconds)
    {// couldn't find the normal java sleep command
        try { Thread.sleep(seconds * 1000L); }
        catch (InterruptedException e) { }
    }

    // asks if the user wants Customers or Robots, returns "Customer", "Robot" or "" if invalid
    private static String chooseType()
    {
        System.out.println("press C, for Customers");
        System.out.println("press R, for Robots");
        String input = s.nextLine().trim().toUpperCase();
        if (input.equals("C"))
            return "Customer";
        else if (input.equals("R"))
            return "Robot";
        System.out.println("Invalid input");
        return "";
    }

    private static void addRecords()
    {
        String type = chooseType();
        if (type.equals("Customer"))
            records.add(new Customer());
        else if (type.equals("Robot"))
            records.add(new Robot());
        else
            return;
        System.out.println(type + " added.");
    }

    // prints every record of one type with a number in front, returns them so the user can pick one
    private static ArrayList<Entity> listRecords(String type)
    {
        ArrayList<Entity> found = new ArrayList<>();
        for (Entity e : records)
        {
            if (e.getEntityName().equals(type))
            {
                found.add(e);
                System.out.print(found.size() + ". ");
                e.printMembers();
            }
        }
        if (found.isEmpty())
            System.out.println("No " + type + " records yet.");
        return found;
    }

    private static void editRecords()
    {
        String type = chooseType();
        if (type.equals(""))
            return;

        ArrayList<Entity> found = listRecords(type);
        if (found.isEmpty())
            return;

        System.out.println("enter the number of the record you want");
        int num;
        try { num = Integer.parseInt(s.nextLine().trim()); }
        catch (NumberFormatException e) { num = -1; }
        if (num < 1 || num > found.size())
        {
            System.out.println("Invalid number");
            return;
        }
        Entity chosen = found.get(num - 1);

        System.out.println("press E, to edit this record");
        System.out.println("press D, to delete this record");
        String input = s.nextLine().trim().toUpperCase();
        if (input.equals("E"))
        {
            chosen.editMembers();
            System.out.println("Record updated.");
        }
        else if (input.equals("D"))
        {
            records.remove(chosen);
            System.out.println("Record deleted.");
        }
        else
            System.out.println("Invalid input");
    }

    private static void searchRecords()
    {
        String type = chooseType();
        if (type.equals(""))
            return;

        if (type.equals("Customer"))
            System.out.println("enter the attribute to search by (CustomerID, First Name, Last Name, Address, Phone number, Email)");
        else
            System.out.println("enter the attribute to search by (Serial Number, Model, Manufacturer, Year, Type, Status)");
        
        String attribute = s.nextLine().trim();
        System.out.println("enter the value to look for");
        String value = s.nextLine().trim();

        boolean any = false;
        for (Entity e : records)
        {
            if (e.getEntityName().equals(type) && value.equalsIgnoreCase(e.getAttribute(attribute)))
            {
                e.printMembers();
                any = true;
            }
        }
        if (!any)
            System.out.println("No matching records found.");
    }

    private static void rentRobot()
    {
        System.out.println("enter CustomerID of the renter");
        String customer = s.nextLine();
        System.out.println("enter Serial Number of the robot");
        String robot = s.nextLine();
        System.out.println("enter rental date (MM/DD/YYYY)");
        String start = s.nextLine();
        System.out.println("enter due date (MM/DD/YYYY)");
        String due = s.nextLine();
        System.out.println("Robot rented.");
    }

    private static void retEquipment()
    {
        System.out.println("enter CustomerID of the renter");
        String customer = s.nextLine();
        System.out.println("enter Serial Number of the robot being returned");
        String robot = s.nextLine();
        System.out.println("enter return date (MM/DD/YYYY)");
        String date = s.nextLine();
        System.out.println("Equipment return documented.");
    }

    private static void deliverRobot()
    {
        System.out.println("enter CustomerID to deliver to");
        String customer = s.nextLine();
        System.out.println("enter Serial Number/s of the robot/s (comma separated)");
        String robots = s.nextLine();
        System.out.println("enter the ID of the driverless car to assign");
        String car = s.nextLine();
        System.out.println("enter delivery date (MM/DD/YYYY)");
        String date = s.nextLine();
        System.out.println("Delivery scheduled.");
    }

    private static void schedulePickup()
    {
        System.out.println("enter CustomerID to pick up from");
        String customer = s.nextLine();
        System.out.println("enter Serial Number/s of the robot/s (comma separated)");
        String robots = s.nextLine();
        System.out.println("enter the ID of the driverless car to assign");
        String car = s.nextLine();
        System.out.println("enter pick up date (MM/DD/YYYY)");
        String date = s.nextLine();
        System.out.println("Pick up scheduled.");
    }
}