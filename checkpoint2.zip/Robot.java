import java.util.Map;
import java.util.LinkedHashMap;

class Robot implements Entity
{
    public String entityName;
    // attribute names first and their matching value as the pair
    private Map<String, String> attributes;

    public Robot()
    {
        entityName = "Robot";
        attributes = new LinkedHashMap<>();
        fillMembers();
    }

    public String getEntityName()
    {
        return entityName;
    }

    public void fillMembers()
    {
        String[] names = {"Serial Number", "Model", "Manufacturer", "Year", "Type", "Status"};
        String[] values;
        do
        {
            System.out.println("in a comma seperatted list enter: Serial Number, Model, Manufacturer, Year, Type, Status");
            String input = main.s.nextLine();
            values = input.split(",", -1);
            if (values.length != names.length)
                System.out.println("expected " + names.length + " values but got " + values.length + ", try again");
        } while (values.length != names.length);

        for (int i = 0; i < names.length; i++)
            attributes.put(names[i], values[i].trim());
    }

    public void editMembers()
    {
        System.out.println("please enter attribute names you would like to change");
        System.out.println("(comma separated, options: " + String.join(", ", attributes.keySet()) + ")");
        String[] names = main.s.nextLine().split(",");
        for (String name : names)
        {
            String key = findKey(name.trim());
            if (key == null)
                System.out.println(name.trim() + " is not an attribute, skipping");
            else
            {
                System.out.println("enter new " + key + " (currently " + attributes.get(key) + ")");
                attributes.put(key, main.s.nextLine().trim());
            }
        }
    }

    public void printMembers()
    {
        System.out.println(entityName + ": " + attributes);
    }

    public String getAttribute(String name)
    {
        String key = findKey(name);
        if (key == null)
            return null;
        return attributes.get(key);
    }

    // finds the attribute name ignoring upper/lower case, null if it doesn't exist
    private String findKey(String name)
    {
        for (String key : attributes.keySet())
            if (key.equalsIgnoreCase(name))
                return key;
        return null;
    }
}