import java.lang.String;

public interface Entity
{
    public String getEntityName();
    public void fillMembers();
    public void editMembers();
    public void printMembers();
    public String getAttribute(String name);
}